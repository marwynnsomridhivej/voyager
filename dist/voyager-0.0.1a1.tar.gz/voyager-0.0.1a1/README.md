# Voyager
Voyager is a fully async API wrapper for the [NASA Open APIs](https://api.nasa.gov/)
written in Python.

I am only the creator of this wrapper library. The APIs are owned and maintained
by their respective maintainers.

If you have any questions or need support, please join the [Voyager Discord 
Support Server](https://discord.gg/D4b9A6Wjwe). *As of right now, the invite 
brings you to the **MarwynnBot Support Server**. You will find a channel named
"voyager" there.*

# Getting Started
To get started with Voyager, you may install it through pip in the following ways:
> **Don't Do it Yet, wait for v1.0.0**